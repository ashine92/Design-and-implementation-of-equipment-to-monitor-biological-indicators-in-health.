#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <NTPClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <Adafruit_MLX90614.h>
#include "MAX30105.h"
#include "heartRate.h"
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// Định nghĩa màu xám tùy chỉnh
#define ST77XX_GRAY 0x8410

// Chân kết nối màn ST7789V2
#define TFT_CS 5
#define TFT_DC 16
#define TFT_RST 17
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_BL 4

// Khởi tạo đối tượng
Adafruit_ST7789 tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);
Adafruit_MLX90614 mlx;
MAX30105 pulseSensor;
Adafruit_MPU6050 mpu;

// Wi-Fi và NTP
const char* ssid = "YOUR_SSID";
const char* password = "YOUR_PASSWORD";
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 25200, 60000);

// Biến tạm
int prevSecond = -1;
float prevTemp = -1000;
int prevBPM = -1;
long stepCount = 0;

// Hàm vẽ các nhãn cố định
void drawStaticElements() {
tft.fillScreen(ST77XX_BLACK);
tft.setTextColor(ST77XX_CYAN);
tft.setTextSize(1);
tft.setCursor(10, 50); tft.print("NHIET DO:");
tft.setCursor(130,50); tft.print("NHIP TIM:");
tft.setCursor(60, 130); tft.print("BƯOC CHAN:");

// Dấu ":" cho đồng hồ
tft.setTextSize(3);
tft.setTextColor(ST77XX_YELLOW);
tft.setCursor(80, 10); tft.print(":");
tft.setCursor(140,10); tft.print(":");
}

void setup() {
Serial.begin(115200);
Wire.begin(21, 22);
pinMode(TFT_BL, OUTPUT);
digitalWrite(TFT_BL, HIGH);

// Khởi màn
tft.init(240, 280);
tft.setRotation(3);
drawStaticElements();

// Kết nối Wi-Fi
WiFi.begin(ssid, password);
while (WiFi.status() != WL_CONNECTED) delay(200);
timeClient.begin();

// Khởi MLX90614
mlx.begin();
// Khởi MAX30102
pulseSensor.begin(); pulseSensor.setup(); pulseSensor.setPulseAmplitudeRed(60);
// Khởi MPU6050
mpu.begin(); mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
}

void loop() {
// Cập nhật đồng hồ
timeClient.update();
int h = timeClient.getHours();
int m = timeClient.getMinutes();
int s = timeClient.getSeconds();
if (s != prevSecond) {
prevSecond = s;
tft.fillRect(10, 10, 160, 30, ST77XX_BLACK);
tft.setTextSize(3);
tft.setTextColor(ST77XX_YELLOW);
tft.setCursor(10, 10);
tft.printf("%02d:%02d:%02d", h, m, s);
}

// Cập nhật nhiệt độ
static unsigned long lastTemp = 0;
if (millis() - lastTemp > 2000) {
lastTemp = millis();
float temp = mlx.readObjectTempC();
if (fabs(temp - prevTemp) > 0.1) {
prevTemp = temp;
tft.fillRect(10, 65, 100, 25, ST77XX_BLACK);
tft.setTextSize(2);
tft.setTextColor(temp > 37.5 ? ST77XX_RED :
temp > 37.0 ? ST77XX_YELLOW : ST77XX_GREEN);
tft.setCursor(10, 65);
tft.printf("%.1fC", temp);
}
}

// Cập nhật nhịp tim
static unsigned long lastBeat = 0;
uint32_t ir = pulseSensor.getIR();
pulseSensor.nextSample();
if (ir > 50000 && checkForBeat(ir)) {
long delta = millis() - lastBeat;
lastBeat = millis();
int bpm = 60000 / delta;
if (bpm >= 40 && bpm <= 200 && bpm != prevBPM) {
prevBPM = bpm;
tft.fillRect(130, 65, 100, 25, ST77XX_BLACK);
tft.setTextSize(2);
tft.setTextColor(bpm > 100 ? ST77XX_RED : ST77XX_MAGENTA);
tft.setCursor(130, 65);
tft.printf("%dBPM", bpm);
}
} else if (ir < 50000 && prevBPM != 0) {
prevBPM = 0;
tft.fillRect(130, 65, 100, 25, ST77XX_BLACK);
tft.setTextSize(2);
tft.setTextColor(ST77XX_GRAY);
tft.setCursor(130,65);
tft.print("--BPM");
}

// Cập nhật bước chân
sensors_event_t a, g, temp;
mpu.getEvent(&a, &g, &temp);
float mag = sqrt(a.acceleration.x*a.acceleration.x +
a.acceleration.y*a.acceleration.y +
a.acceleration.z*a.acceleration.z);
static float lastMag = 0;
static bool stepFlag = false;
if (!stepFlag && fabs(mag - lastMag) > 2.5) {
stepCount++;
stepFlag = true;
} else if (stepFlag && fabs(mag - lastMag) < 1.0) {
stepFlag = false;
}
lastMag = mag;
tft.fillRect(60, 145, 120, 25, ST77XX_BLACK);
tft.setTextSize(2);
tft.setTextColor(ST77XX_GREEN);
tft.setCursor(60, 145);
tft.printf("%ld", stepCount);

delay(50);
}